(new 0); write (get 0)
