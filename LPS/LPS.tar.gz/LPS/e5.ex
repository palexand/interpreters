(new 0);               -- New reference 0
(0 := (get 0) + 5);    -- Increment [0] by 5
(0 := (get 0) + 5);    -- Increment [0] by 5
(write (get 0))        -- print value of [0]

